# --- exercici007resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (100, 200, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')


# Variables globals
font14 = pygame.font.SysFont("Arial", 14)
font22 = pygame.font.SysFont("Arial", 22)
font50 = pygame.font.SysFont("Arial", 50)

mouse_data = { "x": -1, "y": -1, "pressed": False, "released": False }
buttons = [
    { "text": "-", "value": "sub", "x": 25, "y": 25, "width": 50, "height": 25, "pressed": False },
    { "text": "+", "value": "add", "x": 75, "y": 25, "width": 50, "height": 25, "pressed": False },
]

counter = 0

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_data
    mouse_inside = pygame.mouse.get_focused()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_data["x"] = event.pos[0]
                mouse_data["y"] = event.pos[1]
            else:
                mouse_data["x"] = -1
                mouse_data["y"] = -1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_data["pressed"] = True
        elif event.type == pygame.MOUSEBUTTONUP:
            mouse_data["pressed"] = False
            mouse_data["released"] = True

    return True

# Fer càlculs
def app_run():
    global buttons, counter

    for button in buttons:
        if utils.is_point_in_rect(mouse_data, button):
            if mouse_data["pressed"]:
                button["pressed"] = True
            elif mouse_data["released"]:
                button["pressed"] = False   
                if button["value"] == "add": # Aquí fem la operació
                    counter += 1
                else:
                    counter -= 1
        else:
            button["pressed"] = False
    mouse_data["released"] = False  
   
# Dibuixar
def app_draw():
    global pos_x, pos_y

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Draw buttons
    for button in buttons:
        draw_button(button)

    # Draw 'mouse pressed' text
    if mouse_data["pressed"]:
        text = font14.render("Mouse Pressed", True, BLACK)
        screen.blit(text, (135, 30))

    # Dibuixa el comptador
    text_surface = font50.render(str(counter), True, BLACK)
    text_rect = text_surface.get_rect()
    text_rect.centerx = screen.get_width() / 2
    text_rect.centery = screen.get_height() / 2
    screen.blit(text_surface, text_rect)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_button(button):

    color = WHITE
    if button["pressed"]:
        color = ORANGE

    rect_tuple = (button["x"], button["y"], button["width"], button["height"])
    pygame.draw.rect(screen, color, rect_tuple)
    pygame.draw.rect(screen, BLACK, rect_tuple, 2)

    button_center_x = button["x"] + int(button["width"] / 2)
    button_center_y = button["y"] + int(button["height"] / 2)

    text_surface = font22.render(button["text"], True, BLACK)
    text_rect = text_surface.get_rect()
    text_rect.centerx = button_center_x
    text_rect.centery = button_center_y
    screen.blit(text_surface, text_rect)

if __name__ == "__main__":
    main()

# --- exercici008resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (100, 200, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')


# Variables globals
font = pygame.font.SysFont("Arial", 14)

mouse_data = { "x": -1, "y": -1, "pressed": False, "released": False }
buttons = [
    { "value": "up",   "x": 25, "y": 25, "width": 25, "height": 25, "pressed": False },
    { "value": "down", "x": 25, "y": 50, "width": 25, "height": 25, "pressed": False },
]

direction = "up"
position_y = 250
radius = 25

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_data
    mouse_inside = pygame.mouse.get_focused()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_data["x"] = event.pos[0]
                mouse_data["y"] = event.pos[1]
            else:
                mouse_data["x"] = -1
                mouse_data["y"] = -1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_data["pressed"] = True
        elif event.type == pygame.MOUSEBUTTONUP:
            mouse_data["pressed"] = False
            mouse_data["released"] = True

    return True

# Fer càlculs
def app_run():
    global buttons, direction, position_y, radius

    for button in buttons:
        if utils.is_point_in_rect(mouse_data, button):
            if mouse_data["pressed"]:
                button["pressed"] = True
            elif mouse_data["released"]:
                button["pressed"] = False   
                direction = button["value"] # Aquí realitzem la operació
        else:
            button["pressed"] = False
    mouse_data["released"] = False  

    delta_time = clock.get_time() / 1000.0  # Convertir a segons
    speed = 150

    if direction == "up":
        position_y = position_y - speed * delta_time
    else:
        position_y = position_y + speed * delta_time

    min_y = radius
    max_y = screen.get_height() - radius

    if position_y < min_y:
        position_y = min_y
    elif position_y > max_y:
        position_y = max_y

# Dibuixar
def app_draw():
    global pos_x, pos_y

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Draw buttons
    for button in buttons:
        draw_button(button)

    # Draw circle
    center = (500, position_y)
    pygame.draw.circle(screen, BLUE, center, radius)

    # Draw 'mouse pressed' text
    if mouse_data["pressed"]:
        text = font.render("Mouse Pressed", True, BLACK)
        screen.blit(text, (60, 30))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_button(button):

    color = WHITE
    if button["pressed"]:
        color = ORANGE
    elif direction == button["value"]:
        color = BLUE

    rect_tuple = (button["x"], button["y"], button["width"], button["height"])
    pygame.draw.rect(screen, color, rect_tuple)
    pygame.draw.rect(screen, BLACK, rect_tuple, 2)

if __name__ == "__main__":
    main()

# --- exercici009resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (215, 215, 215)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (100, 200, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')


# Variables globals
font = pygame.font.SysFont("Arial", 14)

mouse_data = { "x": -1, "y": -1, "pressed": False, "released": False }
buttons = [
    { "x":  25, "y": 25, "width": 25, "height": 25, "pressed": False, "activated": False },
    { "x":  50, "y": 25, "width": 25, "height": 25, "pressed": False, "activated": False },
    { "x":  75, "y": 25, "width": 25, "height": 25, "pressed": False, "activated": False },
    { "x": 100, "y": 25, "width": 25, "height": 25, "pressed": False, "activated": False },
]

digits = [0, 0, 0, 0]

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_data
    mouse_inside = pygame.mouse.get_focused()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_data["x"] = event.pos[0]
                mouse_data["y"] = event.pos[1]
            else:
                mouse_data["x"] = -1
                mouse_data["y"] = -1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_data["pressed"] = True
        elif event.type == pygame.MOUSEBUTTONUP:
            mouse_data["pressed"] = False
            mouse_data["released"] = True

    return True

# Fer càlculs
def app_run():
    global buttons, digits

    for button in buttons:
        if utils.is_point_in_rect(mouse_data, button):
            if mouse_data["pressed"]:
                button["pressed"] = True
            elif mouse_data["released"]:
                button["pressed"] = False   
                button["activated"] = not button["activated"] # Aquí realitzem la operació
        else:
            button["pressed"] = False
    mouse_data["released"] = False  

    digits[0] = buttons[0]["pressed"] or buttons[0]["activated"]
    digits[1] = buttons[1]["pressed"] or buttons[1]["activated"]
    digits[2] = buttons[2]["pressed"] or buttons[2]["activated"]
    digits[3] = buttons[3]["pressed"] or buttons[3]["activated"]
  
# Dibuixar
def app_draw():
    global digits

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Draw buttons
    for button in buttons:
        draw_button(button)

    # Draw LED number
    draw_LED_number()

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_button(button):
    color = WHITE
    if button["pressed"]:
        color = ORANGE
    elif button["activated"]:
        color = BLUE

    rect_tuple = (button["x"], button["y"], button["width"], button["height"])
    pygame.draw.rect(screen, color, rect_tuple)
    pygame.draw.rect(screen, BLACK, rect_tuple, 2)

def draw_LED_number():
    # Coordenades base per al dígit (part dreta de la pantalla)
    center_x = 400
    center_y = 250
    segment_length = 50
    segment_thick = 5
    left = center_x - int(segment_length / 2)
    right = center_x + int(segment_length / 2)
    top = center_y - segment_length
    bottom = center_y + segment_length

    # Definir posicions per a cada segment
    positions = {
        "htt": { "begin": { "x": left + 4,  "y": top },      "end": { "x": right - 4, "y": top } },
        "hcc": { "begin": { "x": left + 4,  "y": center_y }, "end": { "x": right - 4, "y": center_y } },
        "hbb": { "begin": { "x": left + 4,  "y": bottom },   "end": { "x": right - 4, "y": bottom } },
        "vtl": { "begin": { "x": left,  "y": top + 4 },      "end": { "x": left,  "y": center_y - 4 } },
        "vtr": { "begin": { "x": right, "y": top + 4 },      "end": { "x": right, "y": center_y - 4 } },
        "vbl": { "begin": { "x": left,  "y": center_y + 4 }, "end": { "x": left,  "y": bottom - 4 } },
        "vbr": { "begin": { "x": right, "y": center_y + 4 }, "end": { "x": right, "y": bottom - 4 } },
    }

    # Definir els segments per a cada dígit hexadecimal
    segments = [
        ["htt", "vtr", "vbr", "hbb", "vbl", "vtl"],        # 0
        ["vtr", "vbr"],                                    # 1
        ["htt", "vtr", "hcc", "vbl", "hbb"],               # 2
        ["htt", "vtr", "hcc", "vbr", "hbb"],               # 3
        ["vtl", "vtr", "hcc", "vbr"],                      # 4
        ["htt", "vtl", "hcc", "vbr", "hbb"],               # 5
        ["htt", "vtl", "hcc", "vbl", "vbr", "hbb"],        # 6
        ["htt", "vtr", "vbr"],                             # 7
        ["htt", "vtl", "vtr", "hcc", "vbl", "vbr", "hbb"], # 8
        ["htt", "vtl", "vtr", "hcc", "vbr", "hbb"],        # 9
        ["htt", "vtr", "hcc", "vbl", "vbr", "hbb"],        # a
        ["vtl", "hcc", "vbl", "vbr", "hbb"],               # b
        ["hcc", "vbl", "hbb"],                             # c
        ["vtr", "hcc", "vbr", "hbb", "vbl"],               # d
        ["htt", "vtr", "vtl", "hcc", "vbl", "hbb"],        # e
        ["htt", "vtl", "hcc", "vbl"],                      # f
    ]

    # Determinar el número a dibuixar en hexadecimal
    number = digits[0] * 8 + digits[1] * 4 + digits[2] * 2 + digits[3] * 1

    # Dibuixar totes les posicions (segments)
    for key in positions:
        start = positions[key]["begin"]
        end = positions[key]["end"]
        pygame.draw.line(screen, GRAY, (start["x"], start["y"]), (end["x"], end["y"]), segment_thick)

    # Dibuixar els segments activats del valor
    for segment in segments[number]:
        start = positions[segment]["begin"]
        end = positions[segment]["end"]
        pygame.draw.line(screen, RED, (start["x"], start["y"]), (end["x"], end["y"]), segment_thick)

if __name__ == "__main__":
    main()

# --- exercici010resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import random
import utils

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (220, 220, 220)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Define window size
screen = pygame.display.set_mode((640, 480), pygame.RESIZABLE)
pygame.display.set_caption('Window Title')

# Variables globals
font14 = pygame.font.SysFont("Arial", 14)
font12 = pygame.font.SysFont("Arial", 12)

window_size = { 
    "width": 0, 
    "height": 0, 
    "center": {
        "x": 0,
        "y": 0
    } 
}

mouse_pos = {'x': 300, 'y': 250 }

level = 1  # Level
snake = {
    "queue": [],
    "speed": 50,
    "radius": 7,
    "status": "follow_mouse", # "follow_mouse" or "orbit_mouse"
    "direction_angle": 0
}

piece = { # (food)
    "x": -1, 
    "y": -1, 
    "value": 0,
    "radius": 7
}  

# Bucle de l'aplicació
def main():
    is_looping = True

    init_game()

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()
        clock.tick(60)  # Limit to 60 FPS

    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos

    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # Close window button
            return False
        elif event.type == pygame.MOUSEMOTION:
            mouse_pos['x'], mouse_pos['y'] = event.pos
    return True

# Fer càlculs
def app_run():
    set_window_size()
    delta_time = clock.get_time() / 1000.0  # Convertir a segons

    move_snake(delta_time)

# Dibuixar
def app_draw():
    screen.fill(WHITE)

    draw_board()
    draw_piece()
    draw_snake()
    pygame.display.update()

# Estableix les mides de la finestra
def set_window_size():
    global window_size

    window_size["width"] = screen.get_width()
    window_size["height"] = screen.get_height()
    window_size["center"]["x"] = int(screen.get_width() / 2)
    window_size["center"]["y"] = int(screen.get_height() / 2)

# Iniciar la serp
def init_game():
    global snake

    # Genera la primera peça 
    # (necessita tenir les mides de la finestra)
    set_window_size()
    if piece['x'] == -1:
        generate_piece()

    # Inicia la serp
    # (al centre de la pantalla, i de mida 5)
    snake["points"] = []
    snake["queue"].append({'x': window_size["center"]["x"], 'y': window_size["center"]["y"]})
    for cnt in range(4):
        extend_snake()

def generate_piece():
    piece['x'] = random.randint(100, window_size["width"] - 100)
    piece['y'] = random.randint(100, window_size["height"] - 100)
    piece['value'] = random.randint(1, 4)

def extend_snake():
    # Afegir un nou punt a la cua, copiant/duplicant l'última posició
    ultim = len(snake["queue"]) - 1
    snake["queue"].append({
        "x": snake["queue"][ultim]['x'], 
        "y": snake["queue"][ultim]['y']
    })

def move_snake(delta_time):
    global serp, level

    # Si la serp xoca amb la peça
    hit = utils.is_point_in_circle(snake["queue"][0], piece, piece["radius"])
    if hit:
        level += 1
        snake["speed"] = snake["speed"] * 1.05  # Augmentar velocitat
        if snake["speed"] > 200:    # Limitar velocitat
            snake["speed"] = 200
        for _ in range(piece['value']): # Ampliar la cua de la serp
            extend_snake()              # al número de la peça (menjar)
        generate_piece()

    # Calcular la següent posició
    next_pos = get_next_snake_pos(delta_time)

    # Inserir la nova posició al principi de la cua
    snake["queue"].insert(0, next_pos)

    # Eliminar l'últim segment per mantenir
    snake["queue"].pop()

def get_next_snake_pos(delta_time):
    global snake

    # Calcula la diferència en les coordenades entre el cap de la serp i el ratolí
    delta_x = mouse_pos['x'] - snake["queue"][0]['x']
    delta_y = mouse_pos['y'] - snake["queue"][0]['y']
   
    # Calcula la distància entre el cap de la serp i la posició del ratolí
    distancia = math.hypot(delta_x, delta_y)

    # Determina l'estat de la serp segons la distància al ratolí
    if distancia < 5:
        snake["status"] = 'orbit_mouse'  # Estat per orbitar prop del ratolí
    if distancia > 50:
        snake["status"] = 'follow_mouse'  # Estat per seguir el ratolí

    # Si la serp està en estat d'òrbita, 
    # augmenta l'angle de direcció per fer-la girar
    if snake["status"] == 'orbit_mouse':
        snake["direction_angle"] += distancia * math.pi / 1000
    else:
        # Calcula el pendent per obtenir l'angle; 
        # si delta_x és 0, s'estableix a infinit per evitar divisió per zero
        if delta_x != 0:
            pendent = delta_y / delta_x
        else:
            pendent = float('inf')

        # Calcula l'angle de direcció de la serp per seguir el ratolí
        if delta_x == 0 and mouse_pos['y'] < snake["queue"][0]['y']:
            # Angle per anar amunt (270 graus)
            snake["direction_angle"] = (3 * math.pi) / 2
        elif delta_x == 0 and mouse_pos['y'] >= snake["queue"][0]['y']:
            # Angle per anar avall (90 graus)
            snake["direction_angle"] = math.pi / 2
        elif mouse_pos['x'] > snake["queue"][0]['x']:
            # Angle per anar cap a la dreta 
            snake["direction_angle"] = math.atan(pendent)
        else:
            # Angle per anar cap a l'esquerra (180 graus)
            snake["direction_angle"] = math.atan(pendent) + math.pi

    return {
        "x": snake["queue"][0]['x'] + snake["speed"] * delta_time * math.cos(snake["direction_angle"]), 
        "y": snake["queue"][0]['y'] + snake["speed"] * delta_time * math.sin(snake["direction_angle"])
    }

def draw_board():
    level_text = font14.render(f'Level: {level}', True, BLACK)
    length_text = font14.render(f'Length: {len(snake["queue"])}', True, BLACK)
    speed_text = font14.render(f'Speed: {snake["speed"]:.2f}', True, BLACK)
    screen.blit(level_text, (15, 15))
    screen.blit(length_text, (15, 35))
    screen.blit(speed_text, (15, 55))

def draw_snake():
    for cnt in reversed(range(len(snake["queue"]))):
        cercle = snake["queue"][cnt]
        if len(snake["queue"]) > 1:
            lightness = int((cnt * 225) / (len(snake["queue"]) - 1))
        else:
            lightness = 0
        color = (lightness, lightness, lightness)
        pygame.draw.circle(screen, color, (int(cercle['x']), int(cercle['y'])), snake["radius"])

def draw_piece():
    circle_pos_tuple = (int(piece['x']), int(piece['y']))
    pygame.draw.circle(screen, RED, circle_pos_tuple, piece["radius"])

    text = font12.render(str(piece['value']), True, BLACK)
    text_rect = text.get_rect(center=circle_pos_tuple)
    screen.blit(text, text_rect)

if __name__ == "__main__":
    main()


# --- exercici000resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
PINK = (255, 105, 180)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
     
    for cnt in range(0, 10):
        x = 100 + cnt * 50
        r = 10 + cnt * 2.5
        pygame.draw.circle(screen, GRAY, (x, 225), r)
        pygame.draw.circle(screen, BLUE, (x, 225), r, 2)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici001resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
PINK = (255, 105, 180)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Variables globals
window_size = { 
    "width": 0, 
    "height": 0, 
    "center": {
        "x": 0,
        "y": 0
    } 
}

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    global window_size

    window_size["width"] = screen.get_width()
    window_size["height"] = screen.get_height()
    window_size["center"]["x"] = int(screen.get_width() / 2)
    window_size["center"]["y"] = int(screen.get_height() / 2)

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
     
    for q in range(20, 0, -1):

        perspective = (q / 20)

        q_ample = q * 25 * perspective
        q_alt = q * 20 * perspective

        x = window_size["center"]["x"] - int(q_ample / 2)
        y = window_size["center"]["y"] - int(q_alt / 2)

        parell = (q % 2) == 0
        if parell:
            color = (0, 0, q * 10)  # Color blau
        else:
            color = (0, q * 10, 0)  # Color verd

        q_rect_tuple = (x, y, q_ample, q_alt)
        pygame.draw.rect(screen, color, q_rect_tuple)
        
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici002resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
PINK = (255, 105, 180)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Variables globals
fontArial = pygame.font.SysFont("Arial", 15)

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    pygame.draw.circle(screen, BLUE, (100, 50), 5)
    draw_text("Poma", fontArial, 100, 50, "left", "bottom")

    pygame.draw.circle(screen, BLUE, (100, 100), 5)
    draw_text("Pera", fontArial, 100, 100, "center", "center")

    pygame.draw.circle(screen, BLUE, (100, 150), 5)
    draw_text("Raïm", fontArial, 100, 150, "right", "top")

    pygame.draw.circle(screen, BLUE, (250, 50), 5)
    draw_text("Plàtan", fontArial, 250, 50, "left", "top")

    pygame.draw.circle(screen, BLUE, (250, 100), 5)
    draw_text("Préssec", fontArial, 250, 100, "center", "center")
    
    pygame.draw.circle(screen, BLUE, (250, 150), 5)
    draw_text("Maduixa", fontArial, 250, 150, "right", "bottom")
    
    pygame.display.update()

def draw_text(text, font, x, y, align_x="left", align_y="top"):
        text_surface = font.render(text, True, (0, 0, 0))
        text_rect = text_surface.get_rect()

        # Configurar l'alineació horitzontal
        if align_x == "center":
            text_rect.centerx = x
        elif align_x == "right":
            text_rect.right = x
        else:
            text_rect.left = x

        # Configurar l'alineació vertical
        if align_y == "center":
            text_rect.centery = y
        elif align_y == "bottom":
            text_rect.bottom = y
        else:
            text_rect.top = y

        screen.blit(text_surface, text_rect)
        pygame.draw.line(screen, (0, 0, 0), (x, y), (x + 50, y), 1)

if __name__ == "__main__":
    main()

# --- exercici003resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BLUE = (50, 150, 255)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480), pygame.RESIZABLE)
pygame.display.set_caption('Window Title')

# Variables globals
window_size = { 
    "width": 0, 
    "height": 0, 
    "center": {
        "x": 0,
        "y": 0
    } 
}
mouse_pos = { "x": -1, "y": -1 }

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
    return True

# Fer càlculs
def app_run():
    global window_size

    window_size["width"] = screen.get_width()
    window_size["height"] = screen.get_height()
    window_size["center"]["x"] = int(screen.get_width() / 2)
    window_size["center"]["y"] = int(screen.get_height() / 2)

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Definir mida rectangle exterior
    ext_ample = window_size["width"] - 100
    ext_alt = window_size["height"] - 100
    ext_rect = (50, 50, ext_ample, ext_alt)

    # Dibuixar limits
    pygame.draw.rect(screen, BLACK, ext_rect, 4)

    # Linia vertical
    start_tuple = (window_size["center"]["x"], 0)
    end_tuple = (window_size["center"]["x"], window_size["height"])
    pygame.draw.line(screen, BLACK, start_tuple, end_tuple, 4)

    # Linia horitzontal
    start_tuple = (0, window_size["center"]["y"])
    end_tuple = (window_size["width"], window_size["center"]["y"])
    pygame.draw.line(screen, BLACK, start_tuple, end_tuple, 4)

    # Dibuixar quadre
    q_x = mouse_pos["x"] - 20
    q_y = mouse_pos["y"] - 20

    color = get_color(q_x, q_y, 50, 50, ext_ample, ext_alt)

    rect = (q_x, q_y, 40, 40)
    pygame.draw.rect(screen, color, rect)
    pygame.draw.rect(screen, BLACK, rect, 2)
    
    pygame.display.update()

def get_color(x, y, ext_x, ext_y, ext_ample, ext_alt):
    color = BLACK

    if x < ext_x or x > (ext_x + ext_ample) or y < ext_y or y > (ext_y + ext_alt):
        return color
    
    if x < window_size["center"]["x"]:
        if y < window_size["center"]["y"]:
            return RED
        else: 
            return GREEN
    else:
        if y < window_size["center"]["y"]:
            return BLUE
        else: 
            return YELLOW

if __name__ == "__main__":
    main()

# --- exercici004resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (127, 184, 68)
YELLOW = (240, 187, 64)
ORANGE = (226, 137, 50)
RED = (202, 73, 65)
PURPLE = (135, 65, 152)
BLUE  = (75, 154, 217)
colors = [GREEN, YELLOW, ORANGE, RED, PURPLE, BLUE]

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Variables globals
mouse_pos = { "x": -1, "y": -1 }
dots = []

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            dots.append({ 
                "x": mouse_pos["x"],
                "y": mouse_pos["y"],
                "radius": 25,
                "color": random.choice(colors)
            })
    return True

# Fer càlculs
def app_run():
    global dots

    delta_time = clock.get_time() / 1000.0  # Convertir a segons

    speed = 5 

    for dot in dots:
        dot["radius"] = dot["radius"] - speed * delta_time
        if dot["radius"] < 5:
            dot["radius"] = 5

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Dibuixar punts
    for dot in dots:
        center = (dot["x"], dot["y"])
        pygame.draw.circle(screen, dot["color"], center, dot["radius"])

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici005resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import random
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (127, 184, 68)
YELLOW = (240, 187, 64)
ORANGE = (226, 137, 50)
RED = (202, 73, 65)
PURPLE = (135, 65, 152)
BLUE  = (75, 154, 217)
colors = [GREEN, YELLOW, ORANGE, RED, PURPLE, BLUE]

# Inicialitzar pygame
pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480), pygame.RESIZABLE)
pygame.display.set_caption('Window Title')

# Variables globals del joc
font = pygame.font.SysFont("Arial", 18)
window_size = { 
    "width": 0, 
    "height": 0, 
    "center": {
        "x": 0,
        "y": 0
    } 
}
mouse_pos = { "x": -1, "y": -1 }

balloons_list = []
balloons_dropped = 0
balloons_caught = 0

# Bucle principal de l'aplicació
def main():
    init_game()
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar esdeveniments
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1

    return True

# Actualitzar lògica del joc
def app_run():
    global mouse_pos, balloons_list, balloons_caught

    set_window_size()
    delta_time = clock.get_time() / 1000.0  # Convertir a segons

    for balloon in balloons_list:
        update_balloon(balloon, delta_time)
        collision = utils.is_point_in_circle(mouse_pos, balloon, balloon["radius"])
        if collision:
            balloons_caught += 1
            init_balloon(balloon)

# Dibuixar elements a la pantalla
def app_draw():
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar estadístiques
    display_stats()

    # Dibuixar els globus
    for balloon in balloons_list:
        draw_balloon(balloon)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

# Estableix les mides de la finestra
def set_window_size():
    global window_size

    window_size["width"] = screen.get_width()
    window_size["height"] = screen.get_height()
    window_size["center"]["x"] = int(screen.get_width() / 2)
    window_size["center"]["y"] = int(screen.get_height() / 2)

# Iniciar el joc
def init_game():
    global balloons_list, balloons_dropped, balloons_caught
    balloons_list = []
    balloons_dropped = 0
    balloons_caught = 0

    set_window_size()

    # Afegir 10 globus a la llista de globus
    for i in range(10):
        balloon = {'x': 0, 'y': 0, 'color': '', 'radius': 10, 'speed': 10}
        init_balloon(balloon)
        balloons_list.append(balloon)

# Iniciar/Reiniciar els valors d'un globus
def init_balloon(balloon):
    balloon['x'] = random.randint(10, window_size['width'] - 10)
    balloon['y'] = 10
    balloon['color'] = random.choice(colors)
    balloon['radius'] = random.randint(5, 15)
    balloon['speed'] = balloon['radius'] * 2 + balloons_caught

# Mostrar un cercle individual
def draw_balloon(balloon):
    center_tuple = (int(balloon['x']), int(balloon['y']))
    pygame.draw.circle(screen, balloon['color'], center_tuple, balloon['radius'], 0)

# Mostrar estadístiques
def display_stats():
    caught_text = font.render(f"Caught: {balloons_caught}", True, BLACK)
    dropped_text = font.render(f"Dropped: {balloons_dropped}", True, BLACK)
    screen.blit(caught_text, (10, window_size["height"] - 40))
    screen.blit(dropped_text, (10, window_size["height"] - 20))

# Actualitzar un globus individual
def update_balloon(balloon, delta_time):
    global balloons_dropped
    balloon['y'] = balloon['y'] + balloon['speed'] * delta_time
    if balloon['y'] > window_size["height"]:
        balloons_dropped += 1
        init_balloon(balloon)

if __name__ == "__main__":
    main()


# --- exercici006resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (100, 200, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480), pygame.RESIZABLE)
pygame.display.set_caption('Window Title')


# Variables globals
window_size = { 
    "width": 0, 
    "height": 0, 
    "center": {
        "x": 0,
        "y": 0
    } 
}

BOARD_SIZE = (12, 8)
CELL_SIZE = 50
mouse_pos = { "x": -1, "y": -1 }

img_ship = get_emoji(pygame, "🚢", size=CELL_SIZE)
img_drop = get_emoji(pygame, "🌊", size=CELL_SIZE)
img_bomb = get_emoji(pygame, "💥", size=CELL_SIZE)

board_pos = { "x": -1, "y": -1 }
board = []

# Bucle de l'aplicació
def main():
    is_looping = True

    init_board()

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos, board
    mouse_inside = pygame.mouse.get_focused()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            cell_x = int((mouse_pos["x"] - board_pos["x"]) / CELL_SIZE)
            cell_y = int((mouse_pos["y"] - board_pos["y"]) / CELL_SIZE)

            if 0 <= cell_x < len(board[0]) and 0 <= cell_y < len(board):
                # Si la cel·la és buida, marca-la com a "W"
                if board[cell_y][cell_x] == "":
                    board[cell_y][cell_x] = "W"
                # Si conté una part de vaixell "S" marca com "B"
                elif board[cell_y][cell_x] == "S":
                    board[cell_y][cell_x] = "B"
    return True

# Fer càlculs
def app_run():
    global window_size
    
    window_size["width"] = screen.get_width()
    window_size["height"] = screen.get_height()
    window_size["center"]["x"] = int(screen.get_width() / 2)
    window_size["center"]["y"] = int(screen.get_height() / 2)

    board_pos["x"] = window_size["center"]["x"] - int(len(board[0]) * CELL_SIZE / 2)
    board_pos["y"] = window_size["center"]["y"] - int(len(board) * CELL_SIZE / 2)

# Dibuixar
def app_draw():
    global pos_x, pos_y

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Draw board
    draw_board()

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def place_ship(x, y, length, direction):
    global board
    if direction == "horizontal":
        for i in range(length):
            board[x][y + i] = "S"
    elif direction == "vertical":
        for i in range(length):
            board[x + i][y] = "S"

def is_valid_position(x, y, length, direction):
    max_rows = len(board)
    max_cols = len(board[0])

    # Comprova els límits del tauler i que totes les cel·les estiguin buides
    if direction == "horizontal" and y + length <= max_cols:
        for i in range(length):
            if board[x][y + i] != "":
                return False
            # Comprova els espais de dalt i de baix del vaixell
            if x > 0 and board[x - 1][y + i] != "":
                return False
            if x < max_rows - 1 and board[x + 1][y + i] != "":
                return False
        # Comprova els espais als extrems del vaixell
        if y > 0 and board[x][y - 1] != "":
            return False
        if y + length < max_cols and board[x][y + length] != "":
            return False
        return True

    elif direction == "vertical" and x + length <= max_rows:
        for i in range(length):
            if board[x + i][y] != "":
                return False
            # Comprova els espais a l'esquerra i a la dreta del vaixell
            if y > 0 and board[x + i][y - 1] != "":
                return False
            if y < max_cols - 1 and board[x + i][y + 1] != "":
                return False
        # Comprova els espais als extrems del vaixell
        if x > 0 and board[x - 1][y] != "":
            return False
        if x + length < max_rows and board[x + length][y] != "":
            return False
        return True

    return False

def init_board():
    global board
    board = [["" for _ in range(BOARD_SIZE[0])] for _ in range(BOARD_SIZE[1])]

    ships = [(3, "horizontal"), (4, "horizontal"), (3, "vertical")]
    for ship in ships:
        length = ship[0]
        direction = ship[1]
        placed = False
        while not placed:
            x, y = random.randint(0, len(board) - 1), random.randint(0, len(board[0]) - 1)
            if is_valid_position(x, y, length, direction):
                place_ship(x, y, length, direction)
                placed = True

def draw_board():    
    for i in range(len(board)):
        for j in range(len(board[i])):
            cell_x = board_pos["x"] + j * CELL_SIZE
            cell_y = board_pos["y"] + i * CELL_SIZE
            
            pygame.draw.rect(screen, BLUE, (cell_x, cell_y, CELL_SIZE, CELL_SIZE))

            if board[i][j] == "S":
                screen.blit(img_ship, (cell_x, cell_y))
            elif board[i][j] == "W":
                screen.blit(img_drop, (cell_x, cell_y))
            elif board[i][j] == "B":
                screen.blit(img_ship, (cell_x, cell_y))
                screen.blit(img_bomb, (cell_x, cell_y))

if __name__ == "__main__":
    main()

