# --- exercici020resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir variables globals
board = {
    "position": { 
        "x": 50, 
        "y": 50 
    },
    "size": { 
        "rows": 15, 
        "cols": 10 
    },
    "cell_size": 25
}
mouse_pos = { "x": -1, "y": -1 }
cell_over = { "row": -1, "column": -1 }

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
    return True

# Fer càlculs
def app_run():
    global board, mouse_pos, cell_over
    cell_over = cell_from_point(mouse_pos, board)

# Dibuixar
def app_draw():
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar el taulell
    draw_board(board)

    # Si el ratolí està sobre una cel·la vàlida, dibuixar un rectangle ple en aquesta cel·la
    if cell_over["row"] != -1 and cell_over["column"] != -1:
        cell_position = point_from_cell(cell_over, board)
        if cell_position["x"] != -1 and cell_position["y"] != -1:
            cell_size = board["cell_size"]
            rect_tuple = (cell_position["x"], cell_position["y"], cell_size, cell_size)
            pygame.draw.rect(screen, BLUE, rect_tuple)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_board(board):
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    for row in range(rows):
        for col in range(cols):
            rect_tuple = (x_start + col * cell_size, y_start + row * cell_size, cell_size, cell_size)
            pygame.draw.rect(screen, BLACK, rect_tuple, 1)  # Dibuixar només el contorn de la cel·la

def cell_from_point(point, board):
    x = point["x"]
    y = point["y"]
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    # Comprovar si el punt està dins dels límits del taulell
    if x_start <= x < x_start + cols * cell_size and y_start <= y < y_start + rows * cell_size:
        col = (x - x_start) // cell_size
        row = (y - y_start) // cell_size
        return { "row": row, "column": col }

    # Retornar -1 si està fora dels límits
    return { "row": -1, "column": -1 }

def point_from_cell(cell, board):
    row = cell["row"]
    col = cell["column"]
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    # Comprovar si la cel·la està dins dels límits del taulell
    if 0 <= row < rows and 0 <= col < cols:
        x = x_start + col * cell_size
        y = y_start + row * cell_size
        return { "x": x, "y": y }

    # Retornar -1 si la cel·la està fora dels límits
    return { "x": -1, "y": -1 }

if __name__ == "__main__":
    main()


# --- exercici021resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils


# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (240, 187, 64)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir variables globals
board = {
    "position": { 
        "x": 50, 
        "y": 50 
    },
    "size": { 
        "rows": 15, 
        "cols": 10 
    },
    "cell_size": 25
}
mouse_pos = { "x": -1, "y": -1 }
cell_over = { "row": -1, "column": -1 }
cell_mouse_up = { "row": -1, "column": -1 }
board_values = [[random.randint(0, 9) for _ in range(15)] for _ in range(10)]

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()
        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos, board, cell_mouse_up
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
        elif event.type == pygame.MOUSEBUTTONUP:
            x = event.pos[0]
            y = event.pos[1]
            cell_mouse_up = cell_from_point({ "x": x, "y": y}, board)

    return True

# Fer càlculs
def app_run():
    global board, mouse_pos, cell_over, cell_mouse_up, board_values

    cell_over_tmp = cell_from_point(mouse_pos, board)
    cell_over_value = get_cell_value(cell_over_tmp)
    if cell_over_value != "":
        cell_over = cell_over_tmp
    else:
        cell_over = { "row": -1, "column": -1 }

    if cell_mouse_up["row"] != -1 and cell_mouse_up["column"] != -1:
        # Obtenir el valor de la cel·la sobre la qual s'ha fet mouse up
        mouse_up_value = get_cell_value(cell_mouse_up)
        
        # Recórrer totes les cel·les de board_values
        for row in range(len(board_values)):
            for col in range(len(board_values[row])):
                # Comprovar si el valor de la cel·la coincideix amb mouse_up_value
                if board_values[row][col] == mouse_up_value:
                    # Posar el valor de la cel·la a ""
                    board_values[row][col] = ""

# Dibuixar
def app_draw():
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar el taulell
    draw_board(board)

    # Si el ratolí està sobre una cel·la vàlida
    # dibuixar un rectangle ple en totes les cel·les 
    # que tenen el mateix valor
    if cell_over["row"] != -1 and cell_over["column"] != -1:
        cell_value = get_cell_value(cell_over)
        rows = board["size"]["rows"]
        cols = board["size"]["cols"]
        for row in range(rows):
            for col in range(cols):
                cell_check = { "row": row, "column": col }
                cell_check_value = get_cell_value(cell_check)
                if cell_check_value == cell_value:
                    cell_position = point_from_cell(cell_check, board)
                    cell_size = board["cell_size"]
                    rect = pygame.Rect(cell_position["x"], cell_position["y"], cell_size, cell_size)
                    pygame.draw.rect(screen, YELLOW, rect)

    draw_board_values()

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def get_cell_value(cell):
    global board_values
    if cell["row"] != -1 and cell["column"] != -1:
        row = cell["row"]
        col = cell["column"]
        return board_values[col][row]
    return -1

def draw_board_values():
    global board, board_values
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    # Configurar la font per als números de les cel·les
    font = pygame.font.SysFont(None, 24)

    for row in range(rows):
        for col in range(cols):
            # Obtenir el valor de la cel·la
            cell = { "row": row, "column": col }
            value = get_cell_value(cell)

            # Renderitzar el text i calcular la posició del text al centre de la cel·la
            text_surface = font.render(str(value), True, BLACK)
            text_rect = text_surface.get_rect(center=(x_start + col * cell_size + cell_size / 2,
                                                      y_start + row * cell_size + cell_size / 2))

            # Dibuixar el text al lloc corresponent
            screen.blit(text_surface, text_rect)

def draw_board(board):
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    for row in range(rows):
        for col in range(cols):
            rect = pygame.Rect(x_start + col * cell_size, y_start + row * cell_size, cell_size, cell_size)
            pygame.draw.rect(screen, BLACK, rect, 1)  # Dibuixar només el contorn de la cel·la

def cell_from_point(point, board):
    x = point["x"]
    y = point["y"]
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    # Comprovar si el punt està dins dels límits del taulell
    if x_start <= x < x_start + cols * cell_size and y_start <= y < y_start + rows * cell_size:
        col = (x - x_start) // cell_size
        row = (y - y_start) // cell_size
        return { "row": row, "column": col }

    # Retornar -1 si està fora dels límits
    return { "row": -1, "column": -1 }

def point_from_cell(cell, board):
    row = cell["row"]
    col = cell["column"]
    x_start = board["position"]["x"]
    y_start = board["position"]["y"]
    rows = board["size"]["rows"]
    cols = board["size"]["cols"]
    cell_size = board["cell_size"]

    # Comprovar si la cel·la està dins dels límits del taulell
    if 0 <= row < rows and 0 <= col < cols:
        x = x_start + col * cell_size
        y = y_start + row * cell_size
        return { "x": x, "y": y }

    # Retornar -1 si la cel·la està fora dels límits
    return { "x": -1, "y": -1 }

if __name__ == "__main__":
    main()

# --- exercici022resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)
BROWN = (165, 42, 42)  
YELLOW = (255, 255, 0)  
GREEN = (0, 255, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir variables globals
mouse_pos = { "x": -1, "y": -1 }
heights = [0] * 22 # 22 caselles

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
    return True

# Fer càlculs
def app_run():
    global heights

    cell_width = 25  # Amplada de cada casella
    cell_height = 50  # Altura de cada casella

    # Bucle 1: Comprovar si el ratolí està dins de qualsevol casella
    inside_any_cell = False
    for cnt in range(len(heights)):
        # Posició horitzontal de la casella
        cell_x = 50 + cnt * cell_width
        cell_y_top = 250 - heights[cnt]
        cell_y_bottom = 250

        # Comprovar si el ratolí està dins dels límits d'aquesta casella
        if cell_x <= mouse_pos["x"] < (cell_x + cell_width) and cell_y_top <= mouse_pos["y"] < cell_y_bottom:
            inside_any_cell = True
            break  # Sortir del bucle si ja hem trobat una casella que conté el ratolí

    # Bucle 2: Assignar les alçades segons si el ratolí està dins o fora d'una casella
    for cnt in range(len(heights)):
        cell_x = 50 + cnt * cell_width + (cell_width / 2)  # Centre horitzontal

        if inside_any_cell:
            # Calcular la distància horitzontal
            distance = abs(cell_x - mouse_pos["x"])

            # Normalitzar la distància: propers a mida 50, llunyans a 5
            max_distance = 200  # Distància màxima per al mínim efecte
            heights[cnt] = max(5, 45 - min(distance, max_distance) * (40 / max_distance))
        else:
            # Si el ratolí no està dins de cap casella, fixar totes les alçades a 5
            heights[cnt] = 5

# Dibuixar
def app_draw():
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Graella de fons
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar cada casella amb una alçada basada en la distància
    for cnt in range(len(heights)):
        x = 50 + cnt * 25
        height = 5 + heights[cnt] # Alçada en funció de la distància
        y = 250 - height           # Ajustar perquè creixi cap amunt
        pygame.draw.rect(screen, BLACK, (x, y, 25, height))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici023resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)
BROWN = (165, 42, 42)
YELLOW = (255, 255, 0)
GRAY = (169, 169, 169) 
ORANGE = (255, 165, 0)
GOLD = (255, 215, 0)
RED = (255, 69, 0) 

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir variables globals
font = pygame.font.Font(None, 16)

sun = {
    "pos": { "x": 0, "y": 0 },
    "radius": 20
}
planets = {
    "Mercury": { "distance": 58,  "speed": 47.87, "radius": 3.80, "color": GRAY, "angle": 0, "pos": { "x": 0, "y": 0 } },
    "Venus":   { "distance": 108, "speed": 35.02, "radius": 9.50, "color": GOLD, "angle": 0, "pos": { "x": 0, "y": 0 } },
    "Earth":   { "distance": 150, "speed": 29.78, "radius": 10.0, "color": BLUE, "angle": 0, "pos": { "x": 0, "y": 0 } },
    "Mars":    { "distance": 228, "speed": 24.07, "radius": 5.30, "color": RED,  "angle": 0, "pos": { "x": 0, "y": 0 } },
}

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    global sun, planets
    delta_time = clock.get_time() / 1000.0  
    
     # Posició del Sol al centre de la pantalla
    sun["pos"]["x"] = int(screen.get_width() / 2)
    sun["pos"]["y"] = int(screen.get_height() / 2)

    planet_names = list(planets.keys()) 
    for name in planet_names:
        planet = planets[name]
        planet["angle"] = planet["angle"] + planet["speed"] * delta_time
        distance_from_sun = planet["distance"]
        planet["pos"] = utils.point_on_circle(sun["pos"], distance_from_sun, planet["angle"])

# Dibuixar
def app_draw():
    global sun, planets
    
    screen.fill(BLACK)
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar el Sol
    sun_pos_tuple = (sun["pos"]["x"], sun["pos"]["y"])
    pygame.draw.circle(screen, YELLOW, sun_pos_tuple, sun["radius"])

    # Dibuixar els planetes i les seves òrbites
    for name, planet in planets.items():
                         
        # Dibuixar l'òrbita com a cercle gris (traç de 1 píxel)
        pygame.draw.circle(screen, GRAY, sun_pos_tuple, planet["distance"], 1)
        
        # Dibuixar el planeta a la seva posició
        planet_pos_tuple = (planet["pos"]["x"], planet["pos"]["y"])
        pygame.draw.circle(screen, planet["color"], planet_pos_tuple, planet["radius"])

        # Dibuixar el nom del planeta
        label = font.render(name, True, GRAY)
        label_rect = label.get_rect()
        label_rect.midleft = (planet["pos"]["x"] + planet["radius"] + 5, planet["pos"]["y"]) 
        screen.blit(label, label_rect)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici024resolt.py ---
#!/usr/bin/env python3

import math
import os
from datetime import datetime
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)
RED = (255, 69, 0) 

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir variables globals
font = pygame.font.SysFont("Arial", 16)

time = { 
    "hours": 0, 
    "minutes": 0, 
    "seconds": 0
}

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    global time

    now = datetime.now()
    current_time_ms = now.timestamp() * 1000

    # Hores amb fracció de minuts (format 12 hores)
    time["hours"] = (current_time_ms / 3600000) % 12

    # Minuts amb fracció de segons    
    time["minutes"] = (current_time_ms / 60000) % 60

    # Segons amb fracció de mil·lisegons
    time["seconds"] = (current_time_ms / 1000) % 60

# Dibuixar
def app_draw():   
    global time

    screen.fill(BLACK)
    utils.draw_grid(pygame, screen, 50)

    # Ajust per rotar l'angle d'origen pygame
    # a l'angle 0 d'un rellotge
    offset = -90 

    center = { "x": 325, "y": 250 }
    center_tuple = (center["x"], center["y"])
    radius = 200
    
    # Càlcul de l'angle de les hores 
    degrees_per_hour = (360 / 12)
    hour_angle = (degrees_per_hour * time["hours"]) + offset
    hour = utils.point_on_circle(center, radius * 0.4, hour_angle)
    hour_tuple = (hour["x"], hour["y"])
    pygame.draw.line(screen, WHITE, center_tuple, hour_tuple, 10)

    # Càlcul de l'angle dels minuts 
    degress_per_min = (360 / 60)
    minute_angle = (degress_per_min * time["minutes"]) + offset
    minute = utils.point_on_circle(center, radius * 0.7, minute_angle)
    minute_tuple = (minute["x"], minute["y"])
    pygame.draw.line(screen, BLUE, center_tuple, minute_tuple, 6)

    # Càlcul de l'angle dels segons 
    degress_per_sec = (360 / 60)
    second_angle = (degress_per_sec * time["seconds"]) + offset
    second = utils.point_on_circle(center, radius * 0.9, second_angle)
    second_tuple = (second["x"], second["y"])
    pygame.draw.line(screen, RED, center_tuple, second_tuple, 2)

    # Dibuixar els números
    for num in range(1, 13):
        angle = (degrees_per_hour * num + offset)
        num_pos = utils.point_on_circle(center, radius, angle) 
        num_pos_tuple = (num_pos["x"], num_pos["y"])
        label = font.render(str(num), True, WHITE)
        label_rect = label.get_rect(center=num_pos_tuple)  # Centrar el text
        screen.blit(label, label_rect)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici000resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
PINK = (255, 105, 180)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Dibuixar el quadre rosa
    pygame.draw.rect(screen, PINK, (150, 200, 50, 50), 5)
    
    # Dibuixar el triangle verd
    pygame.draw.polygon(screen, GREEN, [(275, 200), (275 - 28, 248), (275 + 28, 248)], 5)
    
    # Dibuixar la creu blava
    pygame.draw.line(screen, BLUE, (350, 200), (400, 250), 5)
    pygame.draw.line(screen, BLUE, (350, 250), (400, 200), 5)
    
    # Dibuixar la rodona vermella
    pygame.draw.circle(screen, RED, (475, 225), 25, 5)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici001resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (100, 150, 100)
RED = (200, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Fons vermell
    pygame.draw.rect(screen, RED, (50, 50,550, 100))

    # Texts
    fontT = pygame.font.SysFont("Arial", 60)
    text = fontT.render('HEADLINE NEWS', True, WHITE)
    screen.blit(text, (75, 70))

    fontS = pygame.font.SysFont("Courier New", 40, bold=True)
    text = fontS.render('World goes Wrong!', True, BLACK)
    screen.blit(text, (50, 160))

    text = fontS.render('YEP#', True, GREEN)
    screen.blit(text, (510, 155))

    fontB = pygame.font.SysFont("Arial", 28)
    text0 = fontB.render("Lorem ipsum dolor sit amet, consectetur", True, BLACK)
    screen.blit(text0, (50, 250))

    text1 = fontB.render("adipiscing elit, sed do eiusmod tempor", True, BLACK)
    screen.blit(text1, (50, 285))

    text2 = fontB.render("incididunt ut labore et dolore magna aliqua.", True, BLACK)
    screen.blit(text2, (50, 320))

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici002resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    global im_shinnosuke, im_shiro
    is_looping = True

    path_shinnosuke = os.path.join(os.path.dirname(__file__), "./assets/exercici002/shinnosuke.png")
    im_shinnosuke = pygame.image.load(path_shinnosuke).convert_alpha()
    im_shinnosuke = utils.scale_image(pygame, im_shinnosuke, target_width=100)

    path_shiro = os.path.join(os.path.dirname(__file__), "./assets/exercici002/shiro.png")
    im_shiro = pygame.image.load(path_shiro).convert_alpha()
    im_shiro = utils.scale_image(pygame, im_shiro, target_width=75)

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    global im_shinnosuke

    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    screen.blit(im_shinnosuke, (325, 160))
    screen.blit(im_shiro, (225, 205))

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici003resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Bucle cercles
    odd = True
    for cnt in range(225, 0, -25):
        if odd:
            color = RED
        else:
            color = WHITE
        
        pygame.draw.circle(screen, color, (350, 250), cnt)
        odd = not odd

    # Bucle Relleus
    for cnt in range(25, 250, 25):
        pygame.draw.circle(screen, BLACK, (350, 250), cnt, 5)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici004resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Llista aleatòria
list = []

# Bucle de l'aplicació
def main():
    global list

    is_looping = True

    window_width, window_height = screen.get_size()  # Obtenir els límits de la finestra    
    list = [(random.randint(0, window_width), random.randint(0, window_height)) for _ in range(10)]

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    global list

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Dibuixar la llista
    pygame.draw.polygon(screen, BLACK, list, 5)

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici005resolt.py ---
#!/usr/bin/env python3

import math
import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    global list

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)
    
    # Centre de la finstra
    center_x, center_y = int(screen.get_width() / 2), int(screen.get_height() / 2)
    
    # Paràmetres de l'espiral rectangular
    x, y = center_x, center_y
    step = 15  # Longitud inicial del segment
    direction = 0  # 0 = dreta, 1 = amunt, 2 = esquerra, 3 = avall
    
    # Controla el nombre de voltes de l'espiral (25)
    for _ in range(25):  
        # Calcular el punt final de la línia
        if direction == 0:  # Dreta
            end_x, end_y = x + step, y
        elif direction == 1:  # Amunt
            end_x, end_y = x, y - step
        elif direction == 2:  # Esquerra
            end_x, end_y = x - step, y
        elif direction == 3:  # Avall
            end_x, end_y = x, y + step
        
        # Dibuixar la línia
        pygame.draw.line(screen, RED, (x, y), (end_x, end_y), 4)
        
        # Actualitzar el punt inicial per a la següent línia
        x, y = end_x, end_y
        # Canviar la direcció i augmentar la longitud
        direction = (direction + 1) % 4
        step += 15  # Augmentar la longitud per expandir l'espiral

    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici006resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    for row in range(8):
        for column in range(8):
            color = GRAY if (row + column) % 2 == 0 else BLACK
                
            x = 50 + column * 50
            y = 50 + row * 50
            pygame.draw.rect(screen, color, (x, y, 50, 50))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()


if __name__ == "__main__":
    main()

# --- exercici007resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (127, 184, 68)
YELLOW = (240, 187, 64)
ORANGE = (226, 137, 50)
RED = (202, 73, 65)
PURPLE = (135, 65, 152)
BLUE  = (75, 154, 217)
colors = [GREEN, YELLOW, ORANGE, RED, PURPLE, BLUE]

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar quadres
    for q in range (0, len(colors)):
        size = 50
        x = 50 + (q * 100)
        pygame.draw.rect(screen, colors[q], (x, 50, size, size))

        radius = 25
        x = 50 + (q * 100) + radius
        pygame.draw.circle(screen, colors[q], (x, 150 + radius), radius, 2)

    grey = 0
    for q in range (0, 10):
        radius = 25
        x = 50 + (q * 100) + radius
        color = (grey, grey, grey)
        draw_polygon(screen, color, (x, 250 + radius), radius, 3)
        draw_polygon(screen, color, (x, 350 + radius), radius, 5)
        grey = grey + 25

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_polygon(screen, color, center, radius, num_vertices, angle_offset=(math.pi / 3)):
    points = [
        (
            center[0] + radius * math.cos(angle_offset + i * 2 * math.pi / num_vertices),
            center[1] + radius * math.sin(angle_offset + i * 2 * math.pi / num_vertices)
        )
        for i in range(num_vertices)
    ]
    pygame.draw.polygon(screen, color, points)


if __name__ == "__main__":
    main()

# --- exercici008resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir el taulell
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (127, 184, 68)
YELLOW = (240, 187, 64)
ORANGE = (226, 137, 50)
RED = (202, 73, 65)
PURPLE = (135, 65, 152)
BLUE  = (75, 154, 217)

colors = [GREEN, YELLOW, ORANGE, RED, PURPLE, BLUE]
board = [
    [0, 1, 2, 3, 4, 5, 4, 3],
    [1, 2, 3, 4, 5, 4, 3, 2],
    [2, 3, 4, 5, 4, 3, 2, 1],
    [3, 4, 5, 4, 3, 2, 1, 0],
    [4, 5, 4, 3, 2, 1, 0, 1],
    [5, 4, 3, 2, 1, 0, 1, 2],
    [4, 3, 2, 1, 0, 1, 2, 3],
    [3, 2, 1, 0, 1, 2, 3, 4],
]

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    for row in range(len(board)):
        for column in range(len(board[row])):
            cell_value = board[row][column]
            color = colors[cell_value]
                
            x = 50 + column * 50
            y = 50 + row * 50
            rect = (x, y, 50, 50)
            pygame.draw.rect(screen, color, rect)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()


if __name__ == "__main__":
    main()

# --- exercici009resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir les dades
dades = [ 
  {'nom': 'Pelut', 'any': 2018, 'pes': 6.5, 'especie': 'Gos'},
  {'nom': 'Pelat', 'any': 2020, 'pes': 5.0, 'especie': 'Gos'},
  {'nom': 'Mia', 'any': 2022, 'pes': 3.0, 'especie': 'Gat'},
  {'nom': 'Nemo', 'any': 2003, 'pes': 0.1, 'especie': 'Peix'},
  {'nom': 'Mickey', 'any': 1928, 'pes': 0.5, 'especie': 'Ratolí'},
  {'nom': 'Donald', 'any': 1934, 'pes': 0.5, 'especie': 'Ànec'} ]

font0 = pygame.font.SysFont("Arial", 18)
font1 = pygame.font.SysFont("Arial", 16)

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar el fons de la taula
    back = (150, 100, 200, 25 * len(dades))
    pygame.draw.rect(screen, WHITE, back)

    # Dibuixar les linies de les files
    for row_line in range(0, len(dades) + 1):
        y = 100 + row_line * 25
        pygame.draw.line(screen, BLACK, (150, y), (350, y), 2)

    # Dibuixar les dades
    for pos in range(len(dades)):
        item = dades[pos]
        y = 100 + pos * 25 + 2

        textNom = font0.render(item["nom"], True, BLACK)
        screen.blit(textNom, (155, y + 2))

        textAny = font1.render(str(item["any"]), True, BLUE)
        screen.blit(textAny, (255, y + 2))

        textEspecie = font1.render(str(item["especie"]), True, BLUE)
        screen.blit(textEspecie, (305, y + 2))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici010resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (0, 0, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0) 
GOLD = (255, 215, 0)
NAVY = (0, 0, 128)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Variables globals
mouse_pos = { "x": -1, "y": -1 }
rectangles = [
    { "rect": { "x": 50, "y": 100, "width": 250, "height": 50 }, "color": RED },
    { "rect": { "x": 50, "y": 200, "width": 100, "height": 200 }, "color": GOLD },
    { "rect": { "x": 200, "y": 200, "width": 100, "height": 100 }, "color": BLUE },
    { "rect": { "x": 200, "y": 350, "width": 400, "height": 50 }, "color": PURPLE },
    { "rect": { "x": 350, "y": 100, "width": 50, "height": 200 }, "color": ORANGE },
    { "rect": { "x": 450, "y": 100, "width": 150, "height": 100 }, "color": GREEN },
    { "rect": { "x": 450, "y": 250, "width": 150, "height": 50 }, "color": NAVY }
]
collide = -1

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global mouse_pos
    mouse_inside = pygame.mouse.get_focused() # El ratolí està dins de la finestra?

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.MOUSEMOTION:
            if mouse_inside:
                mouse_pos["x"] = event.pos[0]
                mouse_pos["y"] = event.pos[1]
            else:
                mouse_pos["x"] = -1
                mouse_pos["y"] = -1
    return True

# Fer càlculs
def app_run():
    global mouse_pos, collide
    
    collide = -1
    for cnt in range(len(rectangles)):
        obj = rectangles[cnt]
        if utils.is_point_in_rect(mouse_pos, obj["rect"]):
            collide = cnt

# Dibuixar
def app_draw():
    global collide

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Draw rectangles
    for cnt in range(len(rectangles)):
        obj = rectangles[cnt]
        rectangle = obj["rect"]
        rectangle_tuple = (rectangle["x"], rectangle["y"], rectangle["width"], rectangle["height"])

        if collide == cnt:
            pygame.draw.rect(screen, obj["color"], rectangle_tuple)


        pygame.draw.rect(screen, BLACK, rectangle_tuple, 5)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici011resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (0, 0, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Direcció del moviment
dir_x = "none"

# Posició de l'objecte
pos_x = 100
size = 25

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global dir_x, dir_y

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.KEYDOWN:  # Tecla premuda
            if event.key == pygame.K_LEFT:
                dir_x = 'left'
            elif event.key == pygame.K_RIGHT:
                dir_x = 'right'
        elif event.type == pygame.KEYUP:  # Tecla alliberada
            if event.key == pygame.K_LEFT:
                if dir_x == 'left':
                    dir_x = 'none'
            elif event.key == pygame.K_RIGHT:
                if dir_x == 'right':
                    dir_x = 'none'
    return True

# Fer càlculs
def app_run():
    global dir_x, pos_x, size

    delta_time = clock.get_time() / 1000.0  # Convertir a segons
    
    speed = 100  # píxels per segon
    displacement = speed * delta_time

    limit_left = size
    limit_right = screen.get_width() - size

    if (dir_x == "right"):
        pos_x = pos_x + displacement
        if (pos_x > limit_right):
            pos_x = limit_right
    elif (dir_x == "left"):
        pos_x = pos_x - displacement
        if (pos_x < limit_left):
            pos_x = limit_left

    size = 10 + (pos_x / 8)

# Dibuixar
def app_draw():
    global pos_x, pos_y

    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Text informatiu
    font = pygame.font.SysFont("Arial", 24)
    text = font.render('Apreta les tecles (left/right)', True, BLACK)
    screen.blit(text, (50, 50))

    # Dibuixar el cercle
    center = (pos_x, 250)
    pygame.draw.circle(screen, BLACK, center, size)
    
    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici012resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE  = (0, 0, 255)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)  
LIGHT_BLUE = (173, 216, 230)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Posició de l'esquiador
CELL_SIZE = 50

pos_skater = { "row": 0, "column": 0}

img_tree = get_emoji(pygame, "🌲", size=CELL_SIZE)
img_snow = get_emoji(pygame, "❄️", size=CELL_SIZE)
img_sman = get_emoji(pygame, "☃️", size=CELL_SIZE)
img_skater = get_emoji(pygame, "🏂", size=CELL_SIZE)

board = []

# Bucle de l'aplicació
def main():
    is_looping = True

    init_board()

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global pos_skater

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        if event.type == pygame.KEYUP:  # Tecla alliberada
            new_row = pos_skater["row"]
            new_col = pos_skater["column"]
            if event.key == pygame.K_LEFT:
                new_col -= 1
            elif event.key == pygame.K_RIGHT:
                new_col += 1
            elif event.key == pygame.K_UP:
                new_row -= 1
            elif event.key == pygame.K_DOWN:
                new_row += 1
            
            # Comprovar si la nova posició és vàlida abans de moure l'esquiador
            if is_skiable_cell(new_row, new_col):
                pos_skater["row"] = new_row
                pos_skater["column"] = new_col
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar el tauler
    start_x = 50
    start_y = 50
    for row in range(len(board)):
        for col in range(len(board[row])):
            x = start_x + col * CELL_SIZE
            y = start_y + row * CELL_SIZE
            pygame.draw.rect(screen, LIGHT_BLUE, (x, y, CELL_SIZE, CELL_SIZE))

            if board[row][col] != '':
                if board[row][col] == 'T':
                    screen.blit(img_tree, (x, y, CELL_SIZE, CELL_SIZE))
                elif board[row][col] == 'M':
                    screen.blit(img_sman, (x, y, CELL_SIZE, CELL_SIZE))
                elif board[row][col] == 'S':
                    screen.blit(img_snow, (x, y, CELL_SIZE, CELL_SIZE))

    # Dibuixar el personatge
    x = start_x + pos_skater["column"] * CELL_SIZE
    y = start_y + pos_skater["row"] * CELL_SIZE
    screen.blit(img_skater, (x, y, CELL_SIZE, CELL_SIZE))

    pygame.display.update()

def init_board():
    global board
    rows = 8
    cols = 10
    
    board = [['' for _ in range(cols)] for _ in range(rows)]
    
    place_random_letters('T', 9)
    place_random_letters('S', 3)
    place_random_letters('M', 3)

def place_random_letters(letter, count):
    global board

    rows = len(board)
    cols = len(board[0])

    placed = 0
    while placed < count:
        row = random.randint(0, rows - 1)
        col = random.randint(0, cols - 1)
        if row != 0 and col != 0 and board[row][col] == '':
            board[row][col] = letter
            placed += 1

# Comprovar si una casella està buida o té neu
def is_skiable_cell(row, col):
    global board

    is_within_bounds = 0 <= row < len(board) and 0 <= col < len(board[0])
    if not is_within_bounds:
        return False
    
    cell_content = board[row][col]
    return cell_content == '' or cell_content == 'S'

if __name__ == "__main__":
    main()


# --- exercici013resolt.py ---
#!/usr/bin/env python3

import random
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils
from assets.svgmoji.emojis import get_emoji

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Dades del cotxe
path = os.path.join(os.path.dirname(__file__), "./assets/exercici013/car.png")
img_car = pygame.image.load(path).convert_alpha()
img_car = utils.scale_image(pygame, img_car, target_width=15)

path = os.path.join(os.path.dirname(__file__), "./assets/exercici013/circuit.png")
img_circuit = pygame.image.load(path).convert_alpha()
img_circuit = utils.scale_image(pygame, img_circuit, target_height=480)

car = {
    "x": 245,
    "y": 430,
    "angle": 90,
    "speed": 100,
    "img": img_car,
    "direction_x": "none",
    "direction_y": "none",
}

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    global car

    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
        elif event.type == pygame.KEYDOWN:  # Tecla apretada
            if event.key == pygame.K_LEFT:
                car["direction_x"] = "left"
            elif event.key == pygame.K_RIGHT:
                car["direction_x"] = "right"
            elif event.key == pygame.K_UP:
                car["direction_y"] = "up"
            elif event.key == pygame.K_DOWN:
                car["direction_y"] = "down"
        elif event.type == pygame.KEYUP:  # Tecla alliberada
            if event.key == pygame.K_LEFT:
                if car["direction_x"] == "left":
                    car["direction_x"] = "none"
            elif event.key == pygame.K_RIGHT:
                if car["direction_x"] == "right":
                    car["direction_x"] = "none"
            elif event.key == pygame.K_UP:
                if car["direction_y"] == "up":
                    car["direction_y"] = "none"
            elif event.key == pygame.K_DOWN:
                if car["direction_y"] == "down":
                    car["direction_y"] = "none"
    return True

# Fer càlculs
def app_run():
    global car
    delta_time = clock.get_time() / 1000.0  

    if car["direction_x"] == "left":
        car["x"] = car["x"] - car["speed"] * delta_time
        car["angle"] = 90
    elif car["direction_x"] == "right":
        car["x"] = car["x"] + car["speed"] * delta_time
        car["angle"] = 270

    if car["direction_y"] == "up":
        car["y"] = car["y"] - car["speed"] * delta_time
        if car["direction_x"] == "none":
            car["angle"] = 0
        elif car["direction_x"] == "right":
            car["angle"] = 315
        elif car["direction_x"] == "left":
            car["angle"] = 45
    elif car["direction_y"] == "down":
        car["y"] = car["y"] + car["speed"] * delta_time
        if car["direction_x"] == "none":
            car["angle"] = 180
        elif car["direction_x"] == "right":
            car["angle"] = 225
        elif car["direction_x"] == "left":
            car["angle"] = 135

# Dibuixar
def app_draw():
    screen.fill(WHITE)
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar el circuit
    screen.blit(img_circuit, (0,0))

    # Dibuixar el cotxe
    rotated_img = pygame.transform.rotate(car["img"], car["angle"])
    rect = rotated_img.get_rect(center=(car["x"], car["y"]))
    screen.blit(rotated_img, rect)

    pygame.display.update()

if __name__ == "__main__":
    main()


# --- exercici014resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades
    for counter in range(0, 11):
        light = counter * (255 / 10)
        x = 50 + (counter * 50)

        pygame.draw.rect(screen, (light, 0, 0), (x, 150, 50, 50))
        pygame.draw.rect(screen, (0, light, 0), (x, 200, 50, 50))
        pygame.draw.rect(screen, (0, 0, light), (x, 250, 50, 50))
        pygame.draw.rect(screen, (light, light, light), (x, 300, 50, 50))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici015resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades
    columns = 21
    hue_step = (360 / columns)
    for column in range(0, columns):
        x = 50 + column * 25
        hue = hue_step * column

        color = utils.hsl_to_rgb(hue, 1.0, 0.5)
        pygame.draw.rect(screen, color, (x, 200, 25, 25))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici016resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades
    
    rows = 15
    columns = 21
    lgt_step = (1/ rows)
    hue_step = (360 / columns)

    for row in range(0, rows):
        y = 50 + row * 25
        lightness = lgt_step * row
        for column in range(0, columns):
            x = 50 + column * 25
            hue = hue_step * column

            color = utils.hsl_to_rgb(hue, 1.0, lightness)
            pygame.draw.rect(screen, color, (x, y, 25, 25))

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici017resolt.py ---
#!/usr/bin/env python3

import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades
    for angle in range(0, 361, 15):
        
        pos0= utils.point_on_circle({ "x": 300, "y": 250 }, 25, angle)
        pos1 = utils.point_on_circle({ "x": 300, "y": 250 }, 150, angle)

        pos0_tuple = (pos0["x"], pos0["y"])
        pos1_tuple = (pos1["x"], pos1["y"])

        pygame.draw.line(screen, BLACK, pos0_tuple, pos1_tuple, 5)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici018resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades
    center = {"x": 300, "y": 250}
    
    for angle in range(0, 361, 15):
        # Calculate current line points
        p0 = utils.point_on_circle(center, 25, angle)
        p1 = utils.point_on_circle(center, 150, angle)
        
        # Calculate previous line points
        prev_angle = angle - 15
        prev_0 = utils.point_on_circle(center, 25, prev_angle)
        prev_1 = utils.point_on_circle(center, 150, prev_angle)

        # Create color based on angle (optional, for color variation)
        color = utils.hsl_to_rgb(angle, 1.0, 0.5)
        
        # Convert dictionary points to tuples for pygame
        points = [
            (int(p0["x"]), int(p0["y"])),
            (int(p1["x"]), int(p1["y"])),
            (int(prev_1["x"]), int(prev_1["y"])),
            (int(prev_0["x"]), int(prev_0["y"]))
        ]
        
        # Draw polygon between consecutive lines
        pygame.draw.polygon(screen, color, points)


    # Actualitzar el dibuix a la finestra
    pygame.display.update()

if __name__ == "__main__":
    main()

# --- exercici019resolt.py ---
#!/usr/bin/env python3

import math
import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
import sys
import utils

# Definir colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 120, 200)
BROWN = (165, 42, 42)  
YELLOW = (255, 255, 0)  
GREEN = (0, 255, 0)  

pygame.init()
clock = pygame.time.Clock()

# Definir la finestra
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Window Title')

# Definir els moviments
moves_house = [{"direction": "right", "distance": 250}, {"direction": "up", "distance": 200}, {"direction": "left", "distance": 50}, {"direction": "up", "distance": 50}, {"direction": "left", "distance": 50}, {"direction": "up", "distance": 50}, {"direction": "left", "distance": 50}, {"direction": "down", "distance": 50}, {"direction": "left", "distance": 50}, {"direction": "down", "distance": 50}, {"direction": "left", "distance": 50}, {"direction": "down", "distance": 200}]
moves_sun = [{"direction": "right", "distance": 25}, {"direction": "up", "distance": 25}, {"direction": "right", "distance": 25}, {"direction": "up", "distance": 25}, {"direction": "right", "distance": 50}, {"direction": "down", "distance": 25}, {"direction": "right", "distance": 25}, {"direction": "down", "distance": 25}, {"direction": "right", "distance": 25}, {"direction": "down", "distance": 50}, {"direction": "left", "distance": 25}, {"direction": "down", "distance": 25}, {"direction": "left", "distance": 25}, {"direction": "down", "distance": 25}, {"direction": "left", "distance": 50}, {"direction": "up", "distance": 25}, {"direction": "left", "distance": 25}, {"direction": "up", "distance": 25}, {"direction": "left", "distance": 25} ]
moves_car = [{"direction": "up", "distance": 50}, {"direction": "right", "distance": 50}, {"direction": "up", "distance": 50}, {"direction": "right", "distance": 50}, {"direction": "down", "distance": 50}, {"direction": "right", "distance": 50}, {"direction": "down", "distance": 50} ]
moves_grass = [{"direction": "right", "distance": 650}, {"direction": "down", "distance": 100}, {"direction": "left", "distance": 650}]

# Bucle de l'aplicació
def main():
    is_looping = True

    while is_looping:
        is_looping = app_events()
        app_run()
        app_draw()

        clock.tick(60) # Limitar a 60 FPS

    # Fora del bucle, tancar l'aplicació
    pygame.quit()
    sys.exit()

# Gestionar events
def app_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Botó tancar finestra
            return False
    return True

# Fer càlculs
def app_run():
    pass

# Dibuixar
def app_draw():
    # Pintar el fons de blanc
    screen.fill(WHITE)

    # Dibuixar la graella
    utils.draw_grid(pygame, screen, 50)

    # Dibuixar les dades seguint els moviments
    draw_moves(BROWN, (350, 400), moves_house)
    draw_moves(YELLOW, (50, 100), moves_sun)
    draw_moves(BLUE, (100, 400), moves_car)
    draw_moves(GREEN, (0, 400), moves_grass)

    # Actualitzar el dibuix a la finestra
    pygame.display.update()

def draw_moves(color, start_pos, moves):
    x, y = start_pos

    polygon = [start_pos]
    for move in moves:
        direction = move["direction"]
        distance = move["distance"]

        # Determinar la nova posició segons la direcció
        if direction == "up":
            new_x, new_y = x, y - distance
        elif direction == "down":
            new_x, new_y = x, y + distance
        elif direction == "left":
            new_x, new_y = x - distance, y
        elif direction == "right":
            new_x, new_y = x + distance, y
        else:
            continue  # Ignorar direccions desconegudes

        polygon.append((new_x, new_y))

        # Actualitzar la posició per al següent moviment
        x, y = new_x, new_y

    pygame.draw.polygon(screen, color, polygon)

if __name__ == "__main__":
    main()

